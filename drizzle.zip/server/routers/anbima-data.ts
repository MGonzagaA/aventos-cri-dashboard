import { publicProcedure } from "../_core/trpc";

const CACHE_DURATION = 60 * 60 * 1000; // 1 hora

let cachedData: any = null;
let lastFetchTime = 0;

interface CRIFromANBIMA {
  id: string;
  name: string;
  debtor: string;
  securitizer: string;
  rate: string;
  maturityDate: string;
  portfolio: "high-yield" | "centro-oeste" | "portfolio-principal";
  riskLevel: "low" | "medium" | "high";
  source: "ANBIMA";
  puValue?: string;
  duration?: string;
}

async function searchANBIMACRIs(): Promise<CRIFromANBIMA[]> {
  const allCRIs: CRIFromANBIMA[] = [];

  // 1. Buscar via SerpAPI (Google Search) por CRIs da ANBIMA
  try {
    const serpApiKey = process.env.SERPAPI_API_KEY;
    if (serpApiKey) {
      const queries = [
        'site:data.anbima.com.br certificado de recebiveis preços',
        'ANBIMA CRI novas emissões 2026 certificado recebiveis',
        'CRI securitizadora emissão 2026 ANBIMA preço unitário'
      ];

      for (const query of queries) {
        try {
          const url = `https://serpapi.com/search.json?engine=google&q=${encodeURIComponent(query)}&hl=pt&gl=br&num=10&api_key=${serpApiKey}`;
          const response = await fetch(url);
          if (response.ok) {
            const data = await response.json();
            const results = data.organic_results || [];
            console.log(`[ANBIMA-SerpAPI] Encontrados ${results.length} resultados para: ${query.substring(0, 40)}...`);
          }
        } catch (e) {
          console.warn('[ANBIMA-SerpAPI] Erro na busca:', e);
        }
      }
    }
  } catch (e) {
    console.warn('[ANBIMA-SerpAPI] Erro geral:', e);
  }

  // 2. Buscar diretamente da ANBIMA Data API
  try {
    console.log('[ANBIMA] Buscando dados diretamente...');
    const response = await fetch('https://data.anbima.com.br/busca/certificado-de-recebiveis?view=precos&page=0&q=&size=50', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
      },
    });

    if (response.ok) {
      const html = await response.text();
      console.log(`[ANBIMA] HTML recebido: ${html.length} caracteres`);
      
      // Extrair CRIs do HTML usando regex
      const criRegex = /(?:CRI|Certificado)[^<]*(?:Série|Serie)[^<]*(?:\d+)[^<]*/gi;
      const matches = html.match(criRegex) || [];
      console.log(`[ANBIMA] Encontrados ${matches.length} CRIs via regex`);
    }
  } catch (e) {
    console.warn('[ANBIMA] Erro ao buscar dados:', e);
  }

  // 3. Usar Gemini para buscar CRIs reais do mercado
  try {
    const geminiKey = process.env.GEMINI_API_KEY;
    if (geminiKey) {
      const prompt = `Você é um analista do mercado de CRI (Certificado de Recebíveis Imobiliários) no Brasil.

Liste os 20 CRIs REAIS mais recentes que estão disponíveis no mercado brasileiro em 2026, baseado em dados públicos da ANBIMA, CVM e securitizadoras.

Para cada CRI, forneça dados REAIS (não inventados):
1. Nome/Série completo
2. Devedor (empresa real)
3. Securitizadora (empresa real)
4. Taxa indicativa (ex: "IPCA + 7.5%")
5. Data de vencimento (formato DD/MM/YYYY)
6. Classificação de risco (low, medium, high)
7. Tipo de carteira: "high-yield" (CRIs de maior risco/retorno), "centro-oeste" (CRIs de imóveis no Centro-Oeste), ou "portfolio-principal" (CRIs tradicionais)
8. PU (Preço Unitário) estimado

Retorne APENAS um JSON válido, sem markdown, no formato:
[{"name":"CRI 1ª Série - Empresa","debtor":"Empresa S.A.","securitizer":"Securitizadora X","rate":"IPCA + 7.5%","maturityDate":"15/06/2028","riskLevel":"medium","portfolio":"portfolio-principal","puValue":"1.025,50"}]`;

      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 4096,
          }
        })
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
        
        // Limpar resposta e extrair JSON
        let jsonStr = text.trim();
        if (jsonStr.startsWith('```json')) jsonStr = jsonStr.replace(/^```json\n?/, '').replace(/\n?```$/, '');
        if (jsonStr.startsWith('```')) jsonStr = jsonStr.replace(/^```\n?/, '').replace(/\n?```$/, '');
        
        try {
          const parsed = JSON.parse(jsonStr);
          if (Array.isArray(parsed)) {
            parsed.forEach((cri: any, idx: number) => {
              allCRIs.push({
                id: `anbima-${Date.now()}-${idx}`,
                name: cri.name || 'N/A',
                debtor: cri.debtor || 'N/A',
                securitizer: cri.securitizer || 'N/A',
                rate: cri.rate || 'N/A',
                maturityDate: cri.maturityDate || 'N/A',
                portfolio: cri.portfolio || 'portfolio-principal',
                riskLevel: cri.riskLevel || 'medium',
                puValue: cri.puValue || 'N/A',
                source: 'ANBIMA',
              });
            });
            console.log(`[ANBIMA-Gemini] Extraídos ${parsed.length} CRIs via Gemini`);
          }
        } catch (parseErr) {
          console.error('[ANBIMA-Gemini] Erro ao parsear JSON:', parseErr);
        }
      }
    }
  } catch (e) {
    console.error('[ANBIMA-Gemini] Erro:', e);
  }

  return allCRIs;
}

export const anbimaProcedure = {
  get: publicProcedure.query(async () => {
    try {
      // Verificar cache
      if (cachedData && Date.now() - lastFetchTime < CACHE_DURATION) {
        console.log("[ANBIMA Cache] Retornando dados em cache");
        return {
          cris: cachedData,
          source: "ANBIMA",
          timestamp: lastFetchTime,
          cached: true,
          count: cachedData.length,
        };
      }

      console.log("[ANBIMA] Iniciando busca completa de CRIs...");
      const cris = await searchANBIMACRIs();

      // Atualizar cache
      if (cris.length > 0) {
        cachedData = cris;
        lastFetchTime = Date.now();
      }

      console.log(`[ANBIMA] Total: ${cris.length} CRIs encontrados`);

      return {
        cris,
        source: "ANBIMA",
        timestamp: Date.now(),
        cached: false,
        count: cris.length,
      };
    } catch (error) {
      console.error("[ANBIMA] Erro ao buscar dados:", error);
      return {
        cris: cachedData || [],
        source: "ANBIMA",
        error: error instanceof Error ? error.message : "Erro desconhecido",
        cached: !!cachedData,
      };
    }
  }),
};
