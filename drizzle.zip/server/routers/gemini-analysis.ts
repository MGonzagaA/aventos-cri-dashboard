import { publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { z } from "zod";

interface GeminiMessage {
  role: "user" | "model";
  parts: Array<{ text: string }>;
}

interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{ text: string }>;
    };
  }>;
}

// Cache simples em memória
const analysisCache = new Map<string, { result: string; timestamp: number }>();
const CACHE_DURATION = 2 * 60 * 60 * 1000; // 2 horas

// Retry helper with exponential backoff
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 2, baseDelay = 2000): Promise<T> {
  for (let i = 0; i <= maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      if (i === maxRetries) throw error;
      const isRateLimit = error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED');
      if (!isRateLimit && i > 0) throw error;
      const delay = baseDelay * Math.pow(2, i);
      console.log(`[Gemini] Retry ${i + 1}/${maxRetries} após ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw new Error('Max retries exceeded');
}

async function callGeminiAPI(messages: GeminiMessage[]): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  
  // Tentar Gemini primeiro
  if (apiKey) {
    try {
      const result = await withRetry(async () => {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const payload = {
          contents: messages,
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
          }
        };

        console.log('[Gemini] Enviando requisição...');

        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error(`[Gemini] Erro ${response.status}:`, errorText.substring(0, 200));
          throw new Error(`Gemini API error: ${response.status}`);
        }

        const data: GeminiResponse = await response.json();
        
        if (!data.candidates || data.candidates.length === 0) {
          throw new Error('No candidates in response');
        }

        return data.candidates[0].content.parts[0].text;
      });

      if (result) {
        console.log('[Gemini] Resposta obtida com sucesso');
        return result;
      }
    } catch (error: any) {
      console.warn('[Gemini] Falhou, tentando fallback LLM:', error.message);
    }
  }

  // Fallback: usar Manus built-in LLM
  try {
    console.log('[LLM Fallback] Usando Manus built-in LLM...');
    
    // Converter mensagens Gemini para formato OpenAI
    const llmMessages = messages.map(msg => ({
      role: msg.role === 'model' ? 'assistant' as const : 'user' as const,
      content: msg.parts.map(p => p.text).join('\n')
    }));

    const response = await invokeLLM({
      messages: llmMessages
    });

    const content = response.choices?.[0]?.message?.content;
    if (typeof content === 'string' && content.length > 0) {
      console.log('[LLM Fallback] Resposta obtida com sucesso');
      return content;
    }
    
    // Handle array content
    if (Array.isArray(content)) {
      const textParts = content.filter((p: any) => p.type === 'text').map((p: any) => p.text);
      if (textParts.length > 0) {
        return textParts.join('\n');
      }
    }

    console.error('[LLM Fallback] Resposta vazia');
    return '';
  } catch (error: any) {
    console.error('[LLM Fallback] Erro:', error.message);
    return '';
  }
}

export const geminiAnalysisRouter = router({
  analyzeCRI: publicProcedure
    .input(z.object({
      criName: z.string(),
      rate: z.string(),
      maturityDate: z.string(),
      securitizer: z.string(),
      status: z.string()
    }))
    .query(async ({ input }) => {
      const cacheKey = `cri-${input.criName}`;
      
      const cached = analysisCache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log('[Gemini Cache] Retornando análise em cache para:', input.criName);
        return cached.result;
      }

      const prompt = `Você é um analista especializado em Certificados de Recebíveis Imobiliários (CRI) no Brasil. 
      
Analise o seguinte CRI e forneça uma análise breve (máximo 3 parágrafos) sobre:
- Risco e oportunidade
- Comparação com o mercado
- Recomendação de investimento

CRI: ${input.criName}
Taxa: ${input.rate}
Vencimento: ${input.maturityDate}
Securitizadora: ${input.securitizer}
Status: ${input.status}

Responda em português, de forma concisa e profissional.`;

      const messages: GeminiMessage[] = [
        { role: "user", parts: [{ text: prompt }] }
      ];

      const result = await callGeminiAPI(messages);
      
      if (result) {
        analysisCache.set(cacheKey, { result, timestamp: Date.now() });
      }

      return result;
    }),

  analyzeNews: publicProcedure
    .input(z.object({
      title: z.string(),
      summary: z.string()
    }))
    .query(async ({ input }) => {
      const cacheKey = `news-${input.title.substring(0, 30)}`;
      
      const cached = analysisCache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log('[Gemini Cache] Retornando análise de notícia em cache');
        return cached.result;
      }

      const prompt = `Você é um analista de mercado especializado em Certificados de Recebíveis Imobiliários (CRI).

Analise a seguinte notícia sobre o mercado de CRI e indique:
- Impacto no mercado (positivo/negativo/neutro)
- Oportunidades para investidores
- Riscos potenciais

Notícia: ${input.title}
Resumo: ${input.summary}

Responda em português, de forma concisa (máximo 2 parágrafos).`;

      const messages: GeminiMessage[] = [
        { role: "user", parts: [{ text: prompt }] }
      ];

      const result = await callGeminiAPI(messages);
      
      if (result) {
        analysisCache.set(cacheKey, { result, timestamp: Date.now() });
      }

      return result;
    }),

  chat: publicProcedure
    .input(z.object({
      message: z.string(),
      context: z.string().optional()
    }))
    .mutation(async ({ input }) => {
      console.log('[Gemini Chat] Recebida mensagem:', input.message.substring(0, 50) + '...');
      
      const systemPrompt = `Você é um assistente especializado em Certificados de Recebíveis Imobiliários (CRI) no Brasil.
Você fornece análises detalhadas, recomendações e informações sobre o mercado de CRI de forma profissional e educativa.
Sempre responda em português brasileiro.
${input.context ? `Contexto adicional: ${input.context}` : ''}`;

      const messages: GeminiMessage[] = [
        {
          role: "user",
          parts: [{ text: systemPrompt }]
        },
        {
          role: "model",
          parts: [{ text: "Entendido. Sou um assistente especializado em CRI e vou ajudá-lo com análises e informações sobre o mercado." }]
        },
        {
          role: "user",
          parts: [{ text: input.message }]
        }
      ];

      const result = await callGeminiAPI(messages);
      
      if (!result) {
        console.error('[Gemini Chat] Resposta vazia da API');
        return { response: 'Desculpe, não consegui processar sua pergunta no momento. Tente novamente em alguns instantes.' };
      }
      
      console.log('[Gemini Chat] Resposta gerada com sucesso');
      return { response: result };
    }),

  generateRecommendations: publicProcedure
    .input(z.object({
      cris: z.array(z.object({
        name: z.string(),
        rate: z.string(),
        status: z.string()
      }))
    }))
    .query(async ({ input }) => {
      const crisList = input.cris.map(c => `- ${c.name}: ${c.rate} (${c.status})`).join('\n');
      
      const prompt = `Você é um consultor de investimentos especializado em CRI.

Baseado na seguinte carteira de CRIs, gere 3-5 recomendações de investimento prioritárias:

${crisList}

Para cada recomendação, explique:
1. Por que esse CRI é interessante
2. Risco/retorno esperado
3. Horizonte de investimento recomendado

Responda em português, de forma concisa e profissional.`;

      const messages: GeminiMessage[] = [
        { role: "user", parts: [{ text: prompt }] }
      ];

      const result = await callGeminiAPI(messages);
      return result;
    })
});
