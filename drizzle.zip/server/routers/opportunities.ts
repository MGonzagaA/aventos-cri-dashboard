import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { opportunities } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

// Todos os 39 CRIs com dados completos
const ALL_CRIS = [
  // PORTFÓLIO PRINCIPAL (15)
  { id: '1', name: 'CRI 182ª Série - Gafisa', debtor: 'Gafisa S.A.', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 8.5%', maturityDate: '15/05/2026', carteira: 'Portfólio Principal', lastro: 'Alienação Fiduciária de Terrenos', emissionValue: 250 },
  { id: '2', name: 'CRI 45ª Série - Helbor', debtor: 'Helbor Empreendimentos', securitizer: 'Virgo', rate: 'CDI + 2.1%', maturityDate: '20/10/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis de Vendas de Unidades', emissionValue: 180 },
  { id: '3', name: 'CRI 92ª Série - Even', debtor: 'Even Construtora', securitizer: 'True Securitizadora', rate: 'IPCA + 7.2%', maturityDate: '12/12/2027', carteira: 'Portfólio Principal', lastro: 'Hipoteca de Empreendimento', emissionValue: 320 },
  { id: '4', name: 'CRI 101ª Série - Cyrela', debtor: 'Cyrela Brazil Realty', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 6.8%', maturityDate: '10/01/2027', carteira: 'Portfólio Principal', lastro: 'Fluxo de Caixa de Projetos', emissionValue: 450 },
  { id: '5', name: 'CRI 55ª Série - MRV', debtor: 'MRV Engenharia', securitizer: 'Virgo', rate: 'CDI + 1.8%', maturityDate: '22/03/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis MCMV', emissionValue: 200 },
  { id: '6', name: 'CRI 88ª Série - Brookfield', debtor: 'Brookfield Incorporações', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 7.8%', maturityDate: '08/08/2026', carteira: 'Portfólio Principal', lastro: 'Hipoteca de Edifício Comercial', emissionValue: 380 },
  { id: '7', name: 'CRI 73ª Série - Plano & Plano', debtor: 'Plano & Plano Construtora', securitizer: 'Virgo', rate: 'CDI + 3.2%', maturityDate: '15/11/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis de Vendas', emissionValue: 150 },
  { id: '8', name: 'CRI 156ª Série - Tecnisa', debtor: 'Tecnisa S.A.', securitizer: 'True Securitizadora', rate: 'IPCA + 8.1%', maturityDate: '20/06/2027', carteira: 'Portfólio Principal', lastro: 'Alienação Fiduciária', emissionValue: 280 },
  { id: '9', name: 'CRI 62ª Série - Klabin Segall', debtor: 'Klabin Segall Empreendimentos', securitizer: 'Fortesec', rate: 'CDI + 2.5%', maturityDate: '10/09/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis Comerciais', emissionValue: 220 },
  { id: '10', name: 'CRI 119ª Série - Construtora Tenda', debtor: 'Construtora Tenda', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 7.5%', maturityDate: '25/07/2026', carteira: 'Portfólio Principal', lastro: 'Hipoteca de Imóvel', emissionValue: 190 },
  { id: '11', name: 'CRI 47ª Série - Rossi', debtor: 'Rossi Residencial', securitizer: 'Virgo', rate: 'CDI + 4.0%', maturityDate: '30/05/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis de Vendas', emissionValue: 160 },
  { id: '12', name: 'CRI 95ª Série - Direcional', debtor: 'Direcional Engenharia', securitizer: 'True Securitizadora', rate: 'IPCA + 8.3%', maturityDate: '12/04/2027', carteira: 'Portfólio Principal', lastro: 'Fluxo de Caixa', emissionValue: 310 },
  { id: '13', name: 'CRI 71ª Série - Eztec', debtor: 'Eztec Empreendimentos', securitizer: 'Fortesec', rate: 'CDI + 2.8%', maturityDate: '18/10/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis Imobiliários', emissionValue: 240 },
  { id: '14', name: 'CRI 138ª Série - Lavvi', debtor: 'Lavvi Desenvolvimento Imobiliário', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 7.9%', maturityDate: '05/03/2027', carteira: 'Portfólio Principal', lastro: 'Alienação Fiduciária', emissionValue: 270 },
  { id: '15', name: 'CRI 52ª Série - Ativa Investimentos', debtor: 'Ativa Investimentos', securitizer: 'Virgo', rate: 'CDI + 3.5%', maturityDate: '22/08/2026', carteira: 'Portfólio Principal', lastro: 'Recebíveis', emissionValue: 175 },
  // CENTRO-OESTE (12)
  { id: 'co1', name: 'CRI Agro 12ª - Fazenda Rio Doce', debtor: 'Produtor Rural ABC', securitizer: 'Fortesec', rate: 'CDI + 4.5%', maturityDate: '05/06/2026', carteira: 'Centro-Oeste', lastro: 'Imóvel Rural MT', emissionValue: 120 },
  { id: 'co2', name: 'CRI Logística Goiânia', debtor: 'LogGyn Participações', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 9.0%', maturityDate: '18/09/2027', carteira: 'Centro-Oeste', lastro: 'Galpões Logísticos GO', emissionValue: 350 },
  { id: 'co3', name: 'CRI 44ª - Shopping Pantanal', debtor: 'Pantanal Invest', securitizer: 'Virgo', rate: 'IPCA + 8.2%', maturityDate: '12/02/2026', carteira: 'Centro-Oeste', lastro: 'Recebíveis Aluguel MT', emissionValue: 280 },
  { id: 'co4', name: 'CRI Agro 15ª - Fazenda Sucesso', debtor: 'Fazenda Sucesso Ltda', securitizer: 'Fortesec', rate: 'CDI + 5.0%', maturityDate: '30/07/2026', carteira: 'Centro-Oeste', lastro: 'Imóvel Rural MS', emissionValue: 95 },
  { id: 'co5', name: 'CRI Comercial Brasília', debtor: 'Brasília Corporate', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 8.5%', maturityDate: '15/04/2027', carteira: 'Centro-Oeste', lastro: 'Prédio Comercial DF', emissionValue: 320 },
  { id: 'co6', name: 'CRI Agro 18ª - Produtor Goiano', debtor: 'Produtor Goiano S.A.', securitizer: 'Fortesec', rate: 'CDI + 4.8%', maturityDate: '22/06/2026', carteira: 'Centro-Oeste', lastro: 'Imóvel Rural GO', emissionValue: 110 },
  { id: 'co7', name: 'CRI Logística Cuiabá', debtor: 'Logística Centro-Oeste', securitizer: 'True Securitizadora', rate: 'IPCA + 9.2%', maturityDate: '10/08/2027', carteira: 'Centro-Oeste', lastro: 'Galpão Logístico MT', emissionValue: 290 },
  { id: 'co8', name: 'CRI Comercial Goiânia 2ª', debtor: 'Goiânia Comercial', securitizer: 'Virgo', rate: 'CDI + 3.8%', maturityDate: '25/09/2026', carteira: 'Centro-Oeste', lastro: 'Prédio Comercial GO', emissionValue: 200 },
  { id: 'co9', name: 'CRI Agro 20ª - Fazenda Mato Grosso', debtor: 'Fazenda Mato Grosso', securitizer: 'Fortesec', rate: 'CDI + 5.2%', maturityDate: '08/07/2026', carteira: 'Centro-Oeste', lastro: 'Imóvel Rural MT', emissionValue: 140 },
  { id: 'co10', name: 'CRI Residencial Brasília', debtor: 'Brasília Residencial', securitizer: 'OPEA Securitizadora', rate: 'IPCA + 8.8%', maturityDate: '20/05/2027', carteira: 'Centro-Oeste', lastro: 'Prédio Residencial DF', emissionValue: 260 },
  { id: 'co11', name: 'CRI Logística Anápolis', debtor: 'Logística Anápolis', securitizer: 'Virgo', rate: 'CDI + 4.2%', maturityDate: '12/10/2026', carteira: 'Centro-Oeste', lastro: 'Galpão Logístico GO', emissionValue: 180 },
  { id: 'co12', name: 'CRI Comercial Cuiabá', debtor: 'Cuiabá Comercial', securitizer: 'True Securitizadora', rate: 'IPCA + 8.7%', maturityDate: '18/03/2027', carteira: 'Centro-Oeste', lastro: 'Prédio Comercial MT', emissionValue: 240 },
  // HIGH YIELD (12)
  { id: 'hy1', name: 'CRI Estressado - Shopping X', debtor: 'Varejo Total S.A.', securitizer: 'Habitasec', rate: 'IPCA + 14.5%', maturityDate: '30/01/2026', carteira: 'High Yield', lastro: 'Recebíveis de Aluguel', emissionValue: 150 },
  { id: 'hy2', name: 'CRI Reestruturação Hotel', debtor: 'Hoteis Luxo LTDA', securitizer: 'Virgo', rate: 'CDI + 6.0%', maturityDate: '14/07/2027', carteira: 'High Yield', lastro: 'Hipoteca de Imóvel', emissionValue: 200 },
  { id: 'hy3', name: 'CRI Recovery - Varejo SP', debtor: 'Lojas de Rua S.A.', securitizer: 'True Securitizadora', rate: 'IPCA + 18.0%', maturityDate: '05/02/2026', carteira: 'High Yield', lastro: 'Direitos Creditórios', emissionValue: 120 },
  { id: 'hy4', name: 'CRI Turismo - Resort Nordeste', debtor: 'Resort Nordeste S.A.', securitizer: 'Habitasec', rate: 'IPCA + 16.2%', maturityDate: '10/03/2026', carteira: 'High Yield', lastro: 'Hipoteca de Resort', emissionValue: 180 },
  { id: 'hy5', name: 'CRI Reestruturação - Retail Park', debtor: 'Retail Park Empreendimentos', securitizer: 'Virgo', rate: 'CDI + 7.5%', maturityDate: '25/08/2026', carteira: 'High Yield', lastro: 'Recebíveis Comerciais', emissionValue: 160 },
  { id: 'hy6', name: 'CRI Estressado - Loja Departamentos', debtor: 'Lojas Departamentos Brasil', securitizer: 'True Securitizadora', rate: 'IPCA + 15.8%', maturityDate: '20/02/2026', carteira: 'High Yield', lastro: 'Direitos Creditórios', emissionValue: 140 },
  { id: 'hy7', name: 'CRI Turismo - Pousada Litoral', debtor: 'Pousada Litoral Ltda', securitizer: 'Habitasec', rate: 'CDI + 6.5%', maturityDate: '15/09/2026', carteira: 'High Yield', lastro: 'Hipoteca de Pousada', emissionValue: 110 },
  { id: 'hy8', name: 'CRI Recovery - Complexo Comercial', debtor: 'Complexo Comercial S.A.', securitizer: 'Virgo', rate: 'IPCA + 17.5%', maturityDate: '08/01/2026', carteira: 'High Yield', lastro: 'Direitos Creditórios', emissionValue: 190 },
  { id: 'hy9', name: 'CRI Reestruturação - Galeria Comercial', debtor: 'Galeria Comercial Premium', securitizer: 'True Securitizadora', rate: 'CDI + 8.0%', maturityDate: '12/07/2026', carteira: 'High Yield', lastro: 'Recebíveis de Aluguel', emissionValue: 170 },
  { id: 'hy10', name: 'CRI Estressado - Centro Comercial', debtor: 'Centro Comercial Brasil', securitizer: 'Habitasec', rate: 'IPCA + 16.5%', maturityDate: '25/01/2026', carteira: 'High Yield', lastro: 'Direitos Creditórios', emissionValue: 130 },
  { id: 'hy11', name: 'CRI Turismo - Hotel Fazenda', debtor: 'Hotel Fazenda Turismo', securitizer: 'Virgo', rate: 'CDI + 7.2%', maturityDate: '30/06/2026', carteira: 'High Yield', lastro: 'Hipoteca de Hotel', emissionValue: 150 },
  { id: 'hy12', name: 'CRI Recovery - Outlet Center', debtor: 'Outlet Center Empreendimentos', securitizer: 'True Securitizadora', rate: 'IPCA + 19.0%', maturityDate: '15/02/2026', carteira: 'High Yield', lastro: 'Direitos Creditórios', emissionValue: 200 },
];

function parseDate(dateStr: string): Date {
  const [d, m, y] = dateStr.split('/').map(Number);
  return new Date(y, m - 1, d);
}

function daysUntilMaturity(dateStr: string): number {
  const maturity = parseDate(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((maturity.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function mapCarteira(carteira: string): 'high-yield' | 'centro-oeste' {
  if (carteira === 'High Yield') return 'high-yield';
  if (carteira === 'Centro-Oeste') return 'centro-oeste';
  return 'high-yield'; // fallback
}

async function analyzeWithGemini(cri: typeof ALL_CRIS[0], daysLeft: number): Promise<{
  analysis: string;
  riskLevel: 'low' | 'medium' | 'high';
  opportunity: string;
}> {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return { analysis: '', riskLevel: 'medium', opportunity: '' };

    const prompt = `Analise este CRI que está vencendo em ${daysLeft} dias:

CRI: ${cri.name}
Devedor: ${cri.debtor}
Securitizadora: ${cri.securitizer}
Taxa: ${cri.rate}
Vencimento: ${cri.maturityDate} (${daysLeft} dias)
Carteira: ${cri.carteira}
Lastro: ${cri.lastro}
Valor Emissão: R$ ${cri.emissionValue}M

Responda em JSON: {"analysis":"análise breve 2 frases","riskLevel":"low|medium|high","opportunity":"oportunidade de refinanciamento em 1 frase"}`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 512 }
      })
    });

    if (!response.ok) return { analysis: '', riskLevel: 'medium', opportunity: '' };

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        analysis: parsed.analysis || '',
        riskLevel: parsed.riskLevel || 'medium',
        opportunity: parsed.opportunity || ''
      };
    }
    return { analysis: text, riskLevel: 'medium', opportunity: '' };
  } catch {
    return { analysis: '', riskLevel: 'medium', opportunity: '' };
  }
}

export const opportunitiesRouter = router({
  // Monitorar CRIs vencendo (apenas High Yield e Centro-Oeste)
  monitor: publicProcedure.query(async () => {
    try {
      console.log('[Opportunities] Monitorando CRIs vencendo...');
      
      // Filtrar apenas High Yield e Centro-Oeste que vencem nos próximos 180 dias
      const maturingCRIs = ALL_CRIS
        .filter(cri => cri.carteira === 'High Yield' || cri.carteira === 'Centro-Oeste')
        .map(cri => ({ ...cri, daysLeft: daysUntilMaturity(cri.maturityDate) }))
        .filter(cri => cri.daysLeft >= -30 && cri.daysLeft <= 180)
        .sort((a, b) => a.daysLeft - b.daysLeft);

      console.log(`[Opportunities] ${maturingCRIs.length} CRIs vencendo encontrados`);

      // Verificar quais já estão no banco
      const db = await getDb();
      if (!db) return { success: false, found: 0, analyzed: 0, opportunities: [] };

      const existing = await db.select().from(opportunities);
      const existingNames = new Set(existing.map(e => e.criName));

      // Inserir novos CRIs que ainda não estão no banco
      const inserted = [];
      for (const cri of maturingCRIs) {
        if (existingNames.has(cri.name)) continue;

        // Analisar com Gemini
        const analysis = await analyzeWithGemini(cri, cri.daysLeft);

        await db.insert(opportunities).values({
          criName: cri.name,
          debtor: cri.debtor,
          securitizer: cri.securitizer,
          rate: cri.rate,
          maturityDate: cri.maturityDate,
          portfolio: mapCarteira(cri.carteira),
          status: 'pending',
          source: 'internal-maturity',
          geminiAnalysis: analysis.analysis,
          riskLevel: analysis.riskLevel,
          opportunity: analysis.opportunity
        });

        inserted.push({ ...cri, ...analysis });
      }

      return {
        success: true,
        found: maturingCRIs.length,
        analyzed: inserted.length,
        opportunities: inserted
      };
    } catch (error) {
      console.error('[Opportunities] Erro:', error);
      return { success: false, found: 0, analyzed: 0, opportunities: [] };
    }
  }),

  // Listar oportunidades pendentes
  list: publicProcedure
    .input(z.object({
      portfolio: z.enum(['high-yield', 'centro-oeste']).optional(),
      status: z.enum(['pending', 'accepted', 'rejected']).optional()
    }).optional())
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return [];
        
        let result = await db.select().from(opportunities).orderBy(opportunities.discoveredAt);
        
        if (input?.status) {
          result = result.filter(r => r.status === input.status);
        }
        if (input?.portfolio) {
          result = result.filter(r => r.portfolio === input.portfolio);
        }
        
        return result;
      } catch (error) {
        console.error('[Opportunities] Erro ao listar:', error);
        return [];
      }
    }),

  // Aceitar oportunidade - Inserir na base com análise Gemini completa
  accept: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error('Database not available');

        // Buscar oportunidade
        const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, input.id));
        if (!opp) throw new Error('Oportunidade não encontrada');

        // Se não tem análise, gerar com Gemini
        let analysis = opp.geminiAnalysis || '';
        if (!analysis) {
          const criData = ALL_CRIS.find(c => c.name === opp.criName);
          if (criData) {
            const result = await analyzeWithGemini(criData, daysUntilMaturity(criData.maturityDate));
            analysis = result.analysis;
            
            await db.update(opportunities)
              .set({ 
                status: 'accepted', 
                acceptedAt: new Date(),
                geminiAnalysis: analysis,
                riskLevel: result.riskLevel,
                opportunity: result.opportunity
              })
              .where(eq(opportunities.id, input.id));
            
            return { success: true, analysis };
          }
        }

        await db.update(opportunities)
          .set({ status: 'accepted', acceptedAt: new Date() })
          .where(eq(opportunities.id, input.id));

        console.log(`[Opportunities] CRI ${opp.criName} inserido na base de análise`);
        return { success: true, analysis };
      } catch (error) {
        console.error('[Opportunities] Erro ao aceitar:', error);
        return { success: false };
      }
    }),

  // Rejeitar oportunidade
  reject: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(opportunities)
          .set({ status: 'rejected', rejectedAt: new Date() })
          .where(eq(opportunities.id, input.id));

        console.log(`[Opportunities] Oportunidade ${input.id} descartada`);
        return { success: true };
      } catch (error) {
        console.error('[Opportunities] Erro ao rejeitar:', error);
        return { success: false };
      }
    }),

  // Obter detalhes de uma oportunidade
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return null;
        
        const result = await db.select().from(opportunities)
          .where(eq(opportunities.id, input.id));
        return result[0] || null;
      } catch (error) {
        console.error('[Opportunities] Erro ao obter:', error);
        return null;
      }
    })
});
