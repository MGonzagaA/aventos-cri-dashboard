import { publicProcedure, router } from "../_core/trpc";

interface NewsArticle {
  title: string;
  description: string;
  url: string;
  image: string;
  publishedAt: string;
  source: { name: string; url: string };
}

// Cache simples em memória
let newsCache: NewsArticle[] = [];
let cacheTimestamp = 0;
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutos

async function fetchFromGNews(): Promise<NewsArticle[]> {
  const apiKey = process.env.GNEWS_API_KEY;
  if (!apiKey) return [];

  const query = 'CRI "certificado de recebível" emissão';
  const url = `https://gnews.io/api/v4/search?q=${encodeURIComponent(query)}&lang=pt&sortby=publishedAt&max=10&apikey=${apiKey}`;

  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[GNews API] Erro ${response.status}:`, errorText);
    return [];
  }

  const data = await response.json();
  if (!data.articles?.length) return [];

  return data.articles.map((a: any) => ({
    title: a.title,
    description: a.description || a.content?.substring(0, 200) || '',
    url: a.url,
    image: a.image || '',
    publishedAt: a.publishedAt,
    source: a.source
  }));
}

async function fetchFromSerpAPI(): Promise<NewsArticle[]> {
  const apiKey = process.env.SERPAPI_API_KEY;
  if (!apiKey) return [];

  try {
    const queries = [
      'CRI emissão certificado recebível imobiliário 2026',
      'novas emissões CRI securitizadora mercado imobiliário'
    ];

    const allArticles: NewsArticle[] = [];

    for (const query of queries) {
      const url = `https://serpapi.com/search.json?engine=google_news&q=${encodeURIComponent(query)}&hl=pt&gl=br&api_key=${apiKey}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        // Fallback para Google Search regular
        const searchUrl = `https://serpapi.com/search.json?engine=google&q=${encodeURIComponent(query)}&hl=pt&gl=br&num=10&api_key=${apiKey}`;
        const searchResponse = await fetch(searchUrl);
        if (searchResponse.ok) {
          const data = await searchResponse.json();
          const results = data.organic_results || [];
          results.slice(0, 5).forEach((r: any) => {
            allArticles.push({
              title: r.title,
              description: r.snippet || '',
              url: r.link,
              image: r.thumbnail || '',
              publishedAt: r.date || new Date().toISOString(),
              source: { name: r.source || 'Google', url: r.displayed_link || '' }
            });
          });
        }
        continue;
      }

      const data = await response.json();
      const newsResults = data.news_results || [];
      newsResults.slice(0, 5).forEach((r: any) => {
        allArticles.push({
          title: r.title,
          description: r.snippet || '',
          url: r.link,
          image: r.thumbnail || '',
          publishedAt: r.date || new Date().toISOString(),
          source: { name: r.source?.name || 'Google News', url: r.source?.url || '' }
        });
      });
    }

    console.log(`[SerpAPI Fallback] Encontradas ${allArticles.length} notícias`);
    return allArticles;
  } catch (error) {
    console.error('[SerpAPI Fallback] Erro:', error);
    return [];
  }
}

async function fetchNews(): Promise<NewsArticle[]> {
  // Verifica cache
  if (newsCache.length > 0 && Date.now() - cacheTimestamp < CACHE_DURATION) {
    console.log('[News Cache] Retornando dados em cache');
    return newsCache;
  }

  console.log('[News] Buscando notícias de CRI...');

  // Tentar GNews primeiro
  let articles = await fetchFromGNews();

  // Se GNews falhar (limite atingido), usar SerpAPI como fallback
  if (articles.length === 0) {
    console.log('[News] GNews indisponível, usando SerpAPI como fallback...');
    articles = await fetchFromSerpAPI();
  }

  // Atualizar cache
  if (articles.length > 0) {
    newsCache = articles;
    cacheTimestamp = Date.now();
  }

  console.log(`[News] Total: ${articles.length} notícias carregadas`);
  return articles;
}

export const gnewsEmissionsRouter = router({
  get: publicProcedure.query(async () => {
    const articles = await fetchNews();

    return articles.map((article, idx) => ({
      id: `news-${idx}`,
      title: article.title,
      summary: article.description,
      url: article.url,
      source: article.source.name,
      category: 'emissão',
      publishedDate: new Date(article.publishedAt),
      date: new Date(article.publishedAt).toLocaleDateString('pt-BR')
    }));
  })
});
