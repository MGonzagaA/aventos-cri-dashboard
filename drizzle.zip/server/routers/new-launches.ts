import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";

interface NewLaunch {
  id: string;
  title: string;
  emitter: string;
  securitizer: string;
  rate: string;
  indexer: string;
  maturityDate: string;
  guarantees: string;
  rating: string;
  source: string;
  sourceUrl: string;
  publishedDate: string;
  description: string;
}

async function searchNewLaunches(): Promise<NewLaunch[]> {
  const launches: NewLaunch[] = [];

  try {
    // Buscar em SerpAPI por novas emissões CRI
    const serpUrl = `https://serpapi.com/search?engine=google&q=nova%20emiss%C3%A3o%20CRI%202026%20ANBIMA%20CVM&api_key=${process.env.SERPAPI_API_KEY}&num=5&gl=br`;
    
    const serpResponse = await fetch(serpUrl);
    if (serpResponse.ok) {
      const serpData = await serpResponse.json();
      
      if (serpData.organic_results) {
        serpData.organic_results.slice(0, 3).forEach((result: any, idx: number) => {
          launches.push({
            id: `launch-serp-${idx}`,
            title: result.title,
            emitter: 'Emissor não identificado',
            securitizer: 'Securitizadora não identificada',
            rate: 'Taxa não identificada',
            indexer: 'Indexador não identificado',
            maturityDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR'),
            guarantees: 'Garantias não identificadas',
            rating: 'Rating não disponível',
            source: 'SerpAPI - Google Search',
            sourceUrl: result.link,
            publishedDate: new Date().toLocaleDateString('pt-BR'),
            description: result.snippet || ''
          });
        });
      }
    }

    // Buscar em GNews por novas emissões
    const gnewsUrl = `https://gnews.io/api/v4/search?q=nova%20emiss%C3%A3o%20CRI%20ANBIMA&lang=pt&country=br&max=3&apikey=${process.env.GNEWS_API_KEY}`;
    
    const gnewsResponse = await fetch(gnewsUrl);
    if (gnewsResponse.ok) {
      const gnewsData = await gnewsResponse.json();
      
      if (gnewsData.articles) {
        gnewsData.articles.slice(0, 2).forEach((article: any, idx: number) => {
          launches.push({
            id: `launch-gnews-${idx}`,
            title: article.title,
            emitter: 'Emissor não identificado',
            securitizer: 'Securitizadora não identificada',
            rate: 'Taxa não identificada',
            indexer: 'Indexador não identificado',
            maturityDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR'),
            guarantees: 'Garantias não identificadas',
            rating: 'Rating não disponível',
            source: 'GNews',
            sourceUrl: article.url,
            publishedDate: new Date(article.publishedAt).toLocaleDateString('pt-BR'),
            description: article.description || ''
          });
        });
      }
    }

    console.log(`[New Launches] Encontrados ${launches.length} novos lançamentos`);
    return launches;
  } catch (error) {
    console.error('[New Launches] Erro ao buscar novos lançamentos:', error);
    return [];
  }
}

export const newLaunchesRouter = router({
  // Buscar novos lançamentos de CRI
  search: publicProcedure.query(async () => {
    try {
      const launches = await searchNewLaunches();
      return {
        success: true,
        count: launches.length,
        launches
      };
    } catch (error) {
      console.error('[New Launches] Erro na busca:', error);
      return {
        success: false,
        count: 0,
        launches: []
      };
    }
  }),

  // Buscar lançamentos com filtros
  searchFiltered: publicProcedure
    .input(z.object({
      indexer: z.string().optional(),
      minRate: z.number().optional(),
      maxRate: z.number().optional()
    }).optional())
    .query(async ({ input }) => {
      try {
        const launches = await searchNewLaunches();
        
        let filtered = launches;
        
        if (input?.indexer) {
          filtered = filtered.filter(l => 
            l.indexer.toLowerCase().includes(input.indexer!.toLowerCase())
          );
        }
        
        return {
          success: true,
          count: filtered.length,
          launches: filtered
        };
      } catch (error) {
        console.error('[New Launches] Erro na busca filtrada:', error);
        return {
          success: false,
          count: 0,
          launches: []
        };
      }
    })
});
