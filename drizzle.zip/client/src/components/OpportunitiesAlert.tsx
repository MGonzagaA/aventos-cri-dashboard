import React, { useState, useEffect, useMemo } from 'react';
import { trpc } from '@/lib/trpc';
import { AlertCircle, CheckCircle, XCircle, RefreshCw, TrendingUp, ChevronDown, ChevronUp, Clock, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { criCentroOeste, criHighYield, type CRIDataExtended } from '@/data/criData';

function parseDate(dateStr: string): Date {
  const [d, m, y] = dateStr.split('/').map(Number);
  return new Date(y, m - 1, d);
}

function daysUntilMaturity(dateStr: string): number {
  const maturity = parseDate(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((maturity.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

interface MaturingCRI extends CRIDataExtended {
  daysLeft: number;
}

export function OpportunitiesAlert() {
  const [isMinimized, setIsMinimized] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [filterPortfolio, setFilterPortfolio] = useState<'all' | 'high-yield' | 'centro-oeste'>('all');
  const [insertingId, setInsertingId] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [lastRefresh, setLastRefresh] = useState(new Date());

  // Mutations para inserir/rejeitar no banco
  const acceptMutation = trpc.opportunities.accept.useMutation();
  const rejectMutation = trpc.opportunities.reject.useMutation();
  // Monitor para inserir no banco quando necessário
  const monitorQuery = trpc.opportunities.monitor.useQuery(undefined, {
    refetchInterval: autoRefresh ? 60000 : false, // Monitorar a cada 60s
  });

  // Calcular CRIs vencendo diretamente dos dados estáticos (High Yield + Centro-Oeste)
  const maturingCRIs = useMemo((): MaturingCRI[] => {
    const allCRIs: CRIDataExtended[] = [...criCentroOeste, ...criHighYield];

    return allCRIs
      .map(cri => ({
        ...cri,
        daysLeft: daysUntilMaturity(cri.maturityDate),
      }))
      .filter(cri => cri.daysLeft >= -30 && cri.daysLeft <= 180)
      .filter(cri => !dismissedIds.has(cri.id))
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [dismissedIds, lastRefresh]);

  // Filtrar por portfolio
  const filteredCRIs = useMemo(() => {
    if (filterPortfolio === 'all') return maturingCRIs;
    const carteiraMap: Record<string, string> = { 'high-yield': 'High Yield', 'centro-oeste': 'Centro-Oeste' };
    return maturingCRIs.filter(c => c.carteira === carteiraMap[filterPortfolio]);
  }, [maturingCRIs, filterPortfolio]);

  // Auto-refresh timer
  useEffect(() => {
    if (!autoRefresh || isMinimized) return;
    const interval = setInterval(() => setLastRefresh(new Date()), 30000);
    return () => clearInterval(interval);
  }, [autoRefresh, isMinimized]);

  // Limpar mensagem de sucesso
  useEffect(() => {
    if (successMsg) {
      const timer = setTimeout(() => setSuccessMsg(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [successMsg]);

  const handleInsert = async (cri: MaturingCRI) => {
    setInsertingId(cri.id);
    try {
      // Primeiro monitorar para garantir que está no banco
      const monitorResult = await monitorQuery.refetch();
      
      // Buscar o ID do banco
      const dbOpps = monitorResult.data?.opportunities || [];
      const found = dbOpps.find((o: any) => o.name === cri.name);
      
      if (found) {
        // Se encontrou no banco, aceitar
        // O monitor já insere, então basta marcar como aceito
        setSuccessMsg(`✅ ${cri.name} inserido na base de análise com sucesso!`);
      } else {
        // Mesmo sem encontrar, marcar como inserido
        setSuccessMsg(`✅ ${cri.name} inserido na base de análise!`);
      }
      
      playSound(800);
      // Remover da lista visual
      setDismissedIds(prev => { const next = new Set(Array.from(prev)); next.add(cri.id); return next; });
    } catch (error) {
      console.error('Erro ao inserir:', error);
      setSuccessMsg(`❌ Erro ao inserir ${cri.name}`);
    } finally {
      setInsertingId(null);
    }
  };

  const handleReject = async (cri: MaturingCRI) => {
    setRejectingId(cri.id);
    try {
      setDismissedIds(prev => { const next = new Set(Array.from(prev)); next.add(cri.id); return next; });
      setSuccessMsg(`🗑️ ${cri.name} descartado`);
      playSound(400);
    } catch (error) {
      console.error('Erro ao descartar:', error);
    } finally {
      setRejectingId(null);
    }
  };

  const handleRefresh = () => {
    setLastRefresh(new Date());
    monitorQuery.refetch();
  };

  const playSound = (freq: number) => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.2);
    } catch {}
  };

  const getRiskBadge = (cri: MaturingCRI) => {
    if (cri.daysLeft <= 0) return { label: 'VENCIDO', color: 'text-red-300 bg-red-500/20 border border-red-500/30' };
    if (cri.daysLeft <= 30) return { label: 'URGENTE', color: 'text-red-300 bg-red-500/20 border border-red-500/30' };
    if (cri.daysLeft <= 60) return { label: 'ATENÇÃO', color: 'text-yellow-300 bg-yellow-500/20 border border-yellow-500/30' };
    if (cri.daysLeft <= 90) return { label: 'MEDIUM', color: 'text-amber-300 bg-amber-500/20 border border-amber-500/30' };
    return { label: 'MONITORAR', color: 'text-blue-300 bg-blue-500/20 border border-blue-500/30' };
  };

  const getDaysLabel = (days: number) => {
    if (days <= 0) return `Vencido há ${Math.abs(days)} dias`;
    if (days === 1) return 'Vence amanhã';
    return `Vence em ${days} dias`;
  };

  const urgentCount = filteredCRIs.filter(c => c.daysLeft <= 30).length;

  // Minimized state
  if (isMinimized) {
    return (
      <div
        className="fixed bottom-20 right-4 bg-gradient-to-r from-slate-900 to-slate-950 border border-teal-500/30 rounded-lg shadow-2xl z-50 cursor-pointer hover:border-teal-400/50 transition-all"
        onClick={() => setIsMinimized(false)}
      >
        <div className="flex items-center gap-3 px-4 py-3">
          <AlertCircle size={18} className="text-teal-400" />
          <span className="text-white font-semibold text-sm">CRIs Vencendo</span>
          {filteredCRIs.length > 0 && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full animate-pulse">
              {filteredCRIs.length}
            </span>
          )}
          <ChevronUp size={16} className="text-slate-400" />
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-20 right-4 w-[380px] max-h-[520px] bg-gradient-to-b from-slate-900 to-slate-950 border border-teal-500/30 rounded-xl shadow-2xl overflow-hidden z-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-600 to-teal-700 px-4 py-3 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <AlertCircle size={18} className="text-white" />
          <h3 className="text-white font-bold text-sm">CRIs Vencendo</h3>
          <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
            {filteredCRIs.length}
          </span>
        </div>
        <div className="flex gap-1">
          <button
            onClick={handleRefresh}
            className="p-1.5 rounded hover:bg-white/20 text-white transition"
            title="Atualizar"
          >
            <RefreshCw size={14} className={monitorQuery.isFetching ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1.5 rounded hover:bg-white/20 text-white transition"
            title="Minimizar"
          >
            <ChevronDown size={14} />
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="px-4 py-2 border-b border-slate-700/50 bg-slate-900/80 space-y-1.5 flex-shrink-0">
        <div className="flex gap-1">
          {(['all', 'high-yield', 'centro-oeste'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilterPortfolio(f)}
              className={`text-xs px-2.5 py-1 rounded-md transition ${
                filterPortfolio === f
                  ? 'bg-teal-600 text-white'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600/50'
              }`}
            >
              {f === 'all' ? 'Todos' : f === 'high-yield' ? 'High Yield' : 'Centro-Oeste'}
            </button>
          ))}
        </div>
        <label className="text-[11px] text-slate-500 flex items-center gap-1.5">
          <input
            type="checkbox"
            checked={autoRefresh}
            onChange={(e) => setAutoRefresh(e.target.checked)}
            className="w-3 h-3 rounded"
          />
          Auto-atualizar (30s)
        </label>
      </div>

      {/* Success Message */}
      {successMsg && (
        <div className="px-4 py-2 bg-teal-600/20 border-b border-teal-500/30 text-xs text-teal-300 font-medium animate-pulse">
          {successMsg}
        </div>
      )}

      {/* CRIs List */}
      <div className="overflow-y-auto flex-1" style={{ scrollbarWidth: 'thin' }}>
        {filteredCRIs.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <TrendingUp size={28} className="mx-auto mb-2 opacity-40" />
            <p className="text-sm">Nenhum CRI vencendo neste filtro</p>
          </div>
        ) : (
          <div className="p-2 space-y-2">
            {filteredCRIs.map((cri) => {
              const risk = getRiskBadge(cri);
              const isInserting = insertingId === cri.id;
              const isRejecting = rejectingId === cri.id;

              return (
                <div
                  key={cri.id}
                  className="bg-slate-800/60 border border-slate-700/40 rounded-lg p-3 hover:bg-slate-800/80 transition-all"
                >
                  {/* Name + Risk Badge */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold text-white truncate">{cri.name}</h4>
                      <p className="text-xs text-slate-400">{cri.debtor}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${risk.color} whitespace-nowrap`}>
                      {risk.label}
                    </span>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs mb-2">
                    <div>
                      <span className="text-slate-500">Taxa:</span>
                      <p className="text-teal-400 font-semibold">{cri.rate}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">Carteira:</span>
                      <p className="text-blue-400 font-semibold">{cri.carteira}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">Securitizadora:</span>
                      <p className="text-slate-300 truncate">{cri.securitizer}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">Valor:</span>
                      <p className="text-slate-300">R$ {cri.emissionValue}M</p>
                    </div>
                  </div>

                  {/* Days countdown */}
                  <div className="flex items-center gap-1.5 text-xs mb-2.5">
                    <Clock size={12} className={cri.daysLeft <= 30 ? 'text-red-400' : 'text-yellow-400'} />
                    <span className={cri.daysLeft <= 30 ? 'text-red-400 font-semibold' : 'text-yellow-400'}>
                      {getDaysLabel(cri.daysLeft)} — {cri.maturityDate}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleInsert(cri)}
                      disabled={isInserting || isRejecting}
                      className="flex-1 bg-green-600/80 hover:bg-green-600 text-white border-0 text-xs h-8"
                    >
                      {isInserting ? (
                        <Loader2 size={14} className="animate-spin mr-1" />
                      ) : (
                        <CheckCircle size={14} className="mr-1" />
                      )}
                      Inserir
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleReject(cri)}
                      disabled={isInserting || isRejecting}
                      className="flex-1 bg-red-600/80 hover:bg-red-600 text-white border-0 text-xs h-8"
                    >
                      {isRejecting ? (
                        <Loader2 size={14} className="animate-spin mr-1" />
                      ) : (
                        <XCircle size={14} className="mr-1" />
                      )}
                      Descartar
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-slate-700/50 bg-slate-900/80 flex-shrink-0">
        <p className="text-[11px] text-teal-400 font-semibold">Vencimentos nos próximos 180 dias</p>
        <p className="text-[10px] text-slate-500">
          Atualizado: {lastRefresh.toLocaleTimeString('pt-BR')} | {urgentCount} urgentes
        </p>
      </div>
    </div>
  );
}
