import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, X, Bot, Sparkles } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface GeminiChatProps {
  isOpen: boolean;
  onClose: () => void;
  context?: string;
}

const QUICK_ACTIONS = [
  { label: '📊 Analisar carteira', message: 'Analise minha carteira de CRIs e sugira melhorias de diversificação.' },
  { label: '📈 Oportunidades', message: 'Quais são as melhores oportunidades de CRI no mercado atual?' },
  { label: '⚠️ Riscos', message: 'Quais são os principais riscos do mercado de CRI atualmente?' },
];

export function GeminiChat({ isOpen, onClose, context }: GeminiChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Olá! Sou o assistente de CRI da Aventos. Posso analisar CRIs, explicar spreads, avaliar riscos e recomendar oportunidades. Como posso ajudá-lo?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Usar mutation para chat (cada mensagem é uma nova requisição)
  const chatMutation = trpc.gemini.chat.useMutation({
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response || 'Desculpe, não consegui processar sua pergunta. Tente novamente.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    },
    onError: (error) => {
      console.error('[GeminiChat] Erro:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Desculpe, ocorreu um erro ao processar sua pergunta. Tente novamente em alguns instantes.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, chatMutation.isPending]);

  const sendMessage = (text: string) => {
    if (!text.trim() || chatMutation.isPending) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    chatMutation.mutate({
      message: text,
      context: context || ''
    });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-20 right-4 w-[400px] h-[500px] bg-slate-900 rounded-xl shadow-2xl border border-slate-700/50 flex flex-col z-50 overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 bg-gradient-to-r from-teal-600/20 to-emerald-600/20 border-b border-slate-700/50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-teal-500/20 flex items-center justify-center">
            <Bot size={18} className="text-teal-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-sm">Assistente CRI</h3>
            <span className="text-xs text-teal-400">Powered by Gemini</span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white transition p-1 rounded hover:bg-slate-700/50"
        >
          <X size={18} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] px-3 py-2 rounded-lg ${
                message.role === 'user'
                  ? 'bg-teal-600 text-white rounded-br-none'
                  : 'bg-slate-800 text-slate-100 border border-slate-700/50 rounded-bl-none'
              }`}
            >
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
              <span className="text-[10px] opacity-50 mt-1 block text-right">
                {message.timestamp.toLocaleTimeString('pt-BR', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>
          </div>
        ))}

        {chatMutation.isPending && (
          <div className="flex justify-start">
            <div className="bg-slate-800 text-slate-100 px-3 py-2 rounded-lg border border-slate-700/50 rounded-bl-none flex items-center gap-2">
              <Loader2 size={14} className="animate-spin text-teal-400" />
              <span className="text-sm text-slate-400">Analisando...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      {messages.length <= 1 && (
        <div className="px-4 pb-2 flex flex-wrap gap-1.5">
          {QUICK_ACTIONS.map((action, idx) => (
            <button
              key={idx}
              onClick={() => sendMessage(action.message)}
              className="text-xs px-2.5 py-1.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700/50 hover:bg-teal-600/20 hover:text-teal-300 hover:border-teal-500/30 transition"
            >
              {action.label}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-700/50 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Pergunte sobre CRI..."
          className="flex-1 bg-slate-800 text-white text-sm px-3 py-2 rounded-lg border border-slate-700/50 focus:outline-none focus:border-teal-500/50 placeholder:text-slate-500"
          disabled={chatMutation.isPending}
        />
        <Button
          type="submit"
          disabled={chatMutation.isPending || !input.trim()}
          size="sm"
          className="bg-teal-600 hover:bg-teal-700 text-white px-3"
        >
          {chatMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
        </Button>
      </form>
    </div>
  );
}
