import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';

export interface CRIData {
  id: string;
  name: string;
  debtor: string;
  status: 'active' | 'warning' | 'critical';
  code: string;
  rate: string;
  maturityDate: string;
  securitizer: string;
  securitizerId: string;
  downloadLink: string;
  linkType: 'direct' | 'portal';
  lastro: string;
  carteira: 'Portfólio Principal' | 'Centro-Oeste' | 'High Yield';
}

export interface IndicatorData {
  id: string;
  name: string;
  value: string | number;
  trend?: string;
  positive?: boolean;
  desc?: string;
  source?: string;
}

export interface NewsItem {
  id: number | string;
  date?: string;
  publishedDate?: string | Date;
  title: string;
  summary: string;
  source: string;
  url: string;
  category: string;
  displayDate?: string;
  displayTime?: string;
  timestamp?: number;
}

export interface DiscoveryItem {
  id: string;
  name: string;
}

export interface UseCRIDataResult {
  cris: CRIData[] | null;
  indicators: IndicatorData[] | null;
  news: NewsItem[] | null;
  discoveries: DiscoveryItem[] | null;
  loading: boolean;
  error: string | null;
}

export const useCRIData = (): UseCRIDataResult => {
  const [indicators, setIndicators] = useState<IndicatorData[] | null>(null);
  const [news, setNews] = useState<NewsItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Queries tRPC - todas com retry e refetch, mas NÃO bloqueiam renderização
  const { data: indicatorsData, isLoading: indLoading, error: indError } = trpc.indicators.get.useQuery(undefined, {
    retry: 1,
    staleTime: 5 * 60 * 1000,
  });
  const { data: gnewsData, error: gnewsError } = trpc.gnewsEmissions.get.useQuery(undefined, {
    retry: 1,
    staleTime: 30 * 60 * 1000,
  });
  const { data: googleSearchData } = trpc.googleSearch.searchCRI.useQuery(undefined, {
    retry: 1,
    staleTime: 60 * 60 * 1000,
  });
  const { data: launchesData } = trpc.newLaunches.search.useQuery(undefined, {
    retry: 1,
    staleTime: 30 * 60 * 1000,
  });

  useEffect(() => {
    try {
      // Indicadores
      const indicatorsArray = Array.isArray(indicatorsData) ? indicatorsData : [];
      if (indicatorsArray.length > 0) {
        setIndicators(indicatorsArray);
        setError(null);
      }

      // Combina notícias do GNews, Google Search e novos lançamentos
      const gnewsArray = Array.isArray(gnewsData) ? gnewsData : [];
      const googleArray = Array.isArray(googleSearchData) ? googleSearchData : [];
      const launchesArray = Array.isArray(launchesData?.launches) ? launchesData.launches : [];

      const launchesNews = launchesArray.map((launch: any) => ({
        id: launch.id,
        title: launch.title,
        summary: launch.description,
        source: launch.source,
        url: launch.sourceUrl,
        category: 'novo-lançamento',
        publishedDate: launch.publishedDate,
        date: launch.publishedDate
      }));

      const allNews = [...gnewsArray, ...launchesNews, ...googleArray.slice(0, 3)].map((item: any) => {
        const pubDate = new Date((item as any).publishedDate || (item as any).date || new Date());
        const displayDate = pubDate.toLocaleDateString('pt-BR');
        const displayTime = pubDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        return {
          ...item,
          displayDate,
          displayTime,
          timestamp: pubDate.getTime()
        };
      }).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

      if (allNews.length > 0) {
        setNews(allNews as NewsItem[]);
      }
    } catch (err: any) {
      console.error('Erro ao processar dados:', err);
    }
  }, [indicatorsData, gnewsData, googleSearchData, launchesData]);

  // Loading é false se indicadores já carregaram OU se houve erro (para não bloquear)
  // O dashboard deve carregar com dados estáticos imediatamente
  const loading = indLoading && !indicators;

  return {
    cris: null, // CRIs vêm dos dados estáticos no Home.tsx
    indicators,
    news,
    discoveries: null,
    loading,
    error
  };
};
